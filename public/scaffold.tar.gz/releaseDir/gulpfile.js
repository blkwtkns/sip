var gulp = require('gulp');
var bower = require('gulp-bower');
 
gulp.task('bower', function() {
  return bower('./client/bower_components')
    .pipe(gulp.dest('./public/bower_components/'))
});var gulp = require('gulp');
var connect = require('gulp-connect');

gulp.task('connect', function () {
	connect.server({
		root: 'public',
		port: 3000
	});
});
// random text
var l33t = require('gulp');

console.log('you are l33t');

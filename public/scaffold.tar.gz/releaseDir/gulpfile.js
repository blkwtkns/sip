var bower = require('gulp-bower');

gulp.task('bower', function() {
  return bower('./client/bower_components')
    .pipe(gulp.dest('./public/bower_components/'))
});
var imageMin = require('gulp-imagemin');

gulp.task('imageMin', function() {
	gulp.src('./assets/img/*')
		.pipe(imageMin())
		.pipe(gulp.dest('./public/img'));
});
var sass = require('gulp-ruby-sass');

gulp.task('sass', function() {
	return sass('assets/sass/style.sass')
		.pipe(gulp.dest('public/css'));
});
var browserify = require('browserify');
var source = require('vinyl-source-stream');
var buffer = require('vinyl-buffer');
var uglify = require('gulp-uglify');
var sourcemaps = require('gulp-sourcemaps');

gulp.task('browserify', function() {
  return browserify('./client/app.js')
  .bundle()
  .pipe(source('main.js'))
  .pipe(buffer())
  .pipe(uglify())
  .pipe(sourcemaps.init({loadMaps: true}))
  .pipe(sourcemaps.write('./maps'))
  .pipe(gulp.dest('./public/js/'));
});
